#!/usr/local/bin/python3
# NAME: Nestor Alvarez
# FILE: lab1.1.py
# DATE: <2014-06-15 Sun>
# DESC: First Python script: prints Hello, world!
print("Hello, world!")
